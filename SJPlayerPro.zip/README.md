# SJ Player Pro

## GitHub-এ আপলোড করবে যেভাবে
1. এই পুরো `SJPlayerPro` ফোল্ডারটা zip করা আছে — GitHub-এ নতুন repo বানাও (নাম: `SJPlayerPro`)।
2. GitHub web editor / Acode দিয়ে সব ফাইল আপলোড করো, ফোল্ডার স্ট্রাকচার হুবহু রেখে (বিশেষ করে `.github/workflows/build.yml` পাথটা ঠিক রাখা জরুরি)।
3. পুশ করলেই GitHub Actions অটোমেটিক ট্রিগার হবে (Actions ট্যাবে দেখতে পারবে)।
4. বিল্ড শেষ হলে Actions run-এর নিচে "Artifacts" সেকশনে `SJPlayerPro-debug-apk` পাবে — ওখান থেকে APK ডাউনলোড করবে।

## ইঞ্জিন পরিবর্তন: Media3 → libmpv
mpvRex (একটা জনপ্রিয় ওপেন-সোর্স libmpv-ভিত্তিক প্লেয়ার) দেখার পর ইঞ্জিন বদলানো হয়েছে Media3/ExoPlayer থেকে **libmpv**-তে (`mpvRex-libmpv`, mpv-android-এর একটা maintained fork, প্রি-বিল্ট AAR হিসেবে)। কারণ:
- libmpv-এর ভেতরে FFmpeg বান্ডেল করা থাকে — AC-3/DTS/FLAC/WMA এমনিতেই কাজ করে, আলাদা NDK বিল্ড লাগে না।
- Galaxy A13 (Exynos 850)-এ AV1 হার্ডওয়্যার ডিকোডার নেই — libmpv-তে সফটওয়্যার AV1 ডিকোড পাথ এমনিতেই কাজ করবে।
- প্রি-বিল্ট AAR হিসেবে আসে, তাই GitHub Actions-এ NDK সেটআপ লাগছে না, আমাদের বিল্ড পাইপলাইন অক্ষুণ্ণ।
- compileSdk 36 / minSdk 26 — আমাদের প্রজেক্টের সাথে হুবহু মেলে।

**আপডেট:** ডিভাইসে টেস্ট করে কনফার্ম হয়েছে — ভিডিও প্লে হচ্ছে, হার্ডওয়্যার ডিকোড (mediacodec) কাজ করছে, অডিও ঠিক আছে। libmpv ইঞ্জিন সফলভাবে কাজ করছে।

## কী কী কাজ করছে (v1)
- libmpv ইঞ্জিন — বিস্তৃত ফরম্যাট সাপোর্ট (H.264/H.265/AV1 সফটওয়্যার+হার্ডওয়্যার, AC-3, DTS, FLAC, WMA, MP3, AAC, Opus সহ প্রায় সবকিছু, যেহেতু FFmpeg বান্ডেল করা)
- **মিডিয়া লাইব্রেরি** — ডিভাইসের সব ভিডিও একটা গ্রিড ভিউতে (থাম্বনেইলসহ), নাম/তারিখ/দৈর্ঘ্য অনুযায়ী সর্ট, watched/in-progress ব্যাজ
- জেস্চার (ডাবল-ট্যাপ সিক, সোয়াইপ ভলিউম/ব্রাইটনেস)
- গ্লাসমরফিক থিম, animated কন্ট্রোল
- কাস্টম কন্ট্রোল প্যানেল (Play/Pause/Seek/Volume/Mute)
- কল বা স্ক্রিন-শেয়ার চলাকালীন অডিও বিহেভিয়ার সেট করার সেটিংস (Mute / Duck / স্বাভাবিক)
- ফাইল ম্যানেজার থেকে ভিডিও ওপেন করার ইন্টেন্ট সাপোর্ট + লাইব্রেরি থেকে বা "ভিডিও বাছাই করুন" বাটন দিয়ে
- স্থায়ী APK signing (GitHub Secrets সেটআপ করা থাকলে)

## এখনো যা নেই (ইচ্ছাকৃতভাবে বাদ, mpvRex-এ আছে)
- M3U প্লেলিস্ট, folder-tree browsing (breadcrumbs) — এখন MediaStore থেকে flat গ্রিড, ফোল্ডার অনুযায়ী না
- নেটওয়ার্ক স্ট্রিমিং (SMB/WebDAV/FTP)
- HDR-to-SDR টোন ম্যাপিং, ফ্রেম-পারফেক্ট A-B লুপ — libmpv-এর অ্যাডভান্সড শেডার/রেন্ডারিং ফিচার, পরে যোগ করা যাবে
- Auto-resume (সেভ করা পজিশনে অটো-সিক) — position সেভ হচ্ছে (৫ সেকেন্ড পরপর + পজে), কিন্তু ভিডিও খোলার সময় অটোমেটিক সেই পজিশনে সিক করা এখনো নেই

## APK Signing (permanent install)
এতদিন শুধু debug APK বিল্ড হচ্ছিল — সেটা প্রতিবার নতুন সিগনেচার দিয়ে বানে, তাই আপডেট করতে গেলে আগেরটা uninstall করা লাগে, আর ডেটা/সেটিংস হারিয়ে যায়। এখন একটা আসল, স্থায়ী (২০৫৩ পর্যন্ত ভ্যালিড) signing key বানিয়ে দিয়েছি, যাতে একই সিগনেচার দিয়ে বারবার আপডেট APK বানানো যায়।

**⚠️ keystore ফাইলটা (`sj-player-pro-release.jks`) হারিয়ে ফেললে ভবিষ্যতে আর কখনো এই একই অ্যাপ আইডেন্টিটি দিয়ে আপডেট বানানো যাবে না — নিরাপদ জায়গায় (Google Drive/একাধিক জায়গায়) ব্যাকআপ রাখো।**

**GitHub Secrets সেটআপ (একবারই করতে হবে):**
1. repo-তে যাও → Settings → Secrets and variables → Actions → "New repository secret"
2. চারটা secret যোগ করো:

| Secret নাম | মান |
|---|---|
| `SJ_KEYSTORE_BASE64` | `keystore_base64.txt` ফাইলের ভেতরের পুরো টেক্সট (একটাই লম্বা লাইন) |
| `SJ_KEYSTORE_PASSWORD` | `SJPlayer2026Pro` |
| `SJ_KEY_ALIAS` | `sjplayerpro` |
| `SJ_KEY_PASSWORD` | `SJPlayer2026Pro` |

3. secrets যোগ করার পর যেকোনো নতুন পুশেই (বা "Re-run jobs" দিলেও) signed release APK বিল্ড হবে — Actions-এর আর্টিফ্যাক্টে `SJPlayerPro-release-apk-signed` নামে পাবে।
4. secrets ছাড়া বিল্ড আগের মতোই চলবে (শুধু debug APK), কিছু ভাঙবে না — তাই এখনই সেটআপ না করলেও সমস্যা নেই।


| জিনিস | ভার্সন | কেন |
|---|---|---|
| AGP | 8.10.0 | KSP 2.3.10-এর এক্সপ্লিসিট মিনিমাম রিকোয়ারমেন্ট ("minimum supported AGP version is 8.10.0")। compileSdk 36 সাপোর্ট কনফার্মড, AGP9 এড়িয়ে |
| Gradle | 8.11.1 | AGP-এর মিনিমাম রিকোয়ারমেন্ট |
| Kotlin | 2.3.10 | Hilt 2.58 শুধু metadata format 2.3.0 পর্যন্ত পড়তে পারে; Kotlin 2.4.x এই format ভাঙে (Hilt-এর লেটেস্ট ভার্সনেও অমীমাংসিত bug)। Kotlin-এর নিজের ডকুমেন্টেশনই "AGP 8.x + Kotlin 2.3.10" রেকমেন্ড করে |
| KSP | 2.3.10 | KSP 2.3.0+ থেকে Kotlin ভার্সনের সাথে independent, তাই অপরিবর্তিত থাকতে পারে |
| Compose BOM | 2026.01.00 | compileSdk 37/AGP9 বাধ্যতামূলক হওয়ার আগের লেটেস্ট স্টেবল লাইন |
| libmpv | mpvRex-libmpv v0.0.8 | mpvRex (real, active, 340+ star প্রজেক্ট)-এর ব্যবহৃত exact ভার্সন, প্রি-বিল্ট AAR |
| Room | 2.8.4 | Room 3.0 এসেছে কিন্তু এটা খুবই সাম্প্রতিক (২০২৬), major breaking rewrite (নতুন প্যাকেজ, coroutine-only) — আমাদের KMP দরকার নেই, তাই প্রমাণিত 2.x লাইন নেওয়া হয়েছে |
| Navigation Compose | 2.9.7 | একই যুক্তি — নতুন Navigation3 কয়েক মাস আগেই স্টেবল হয়েছে, ভিন্ন API মডেল; 2.9.7 প্রমাণিত ও Google-এর নিজস্ব ডকুমেন্টেশনে কনফার্মড কারেন্ট |
| Hilt | 2.58 | 2.59+ AGP9 বাধ্যতামূলক করেছে; 2.58 শেষ AGP8-কম্প্যাটিবল ভার্সন |
| compileSdk/targetSdk | 36 | mpvRex নিজেও এই একই compileSdk ব্যবহার করে |
| minSdk | 26 | legacy PNG launcher icon এড়াতে + mpvRex-এর নিজের minSdk-এর সাথেও মেলে |

বিল্ড ফেইল করলে এরর মেসেজ পুরোটা কপি করে পাঠিও — root cause ধরে ঠিক করে দেব, গেস-বেসড ফিক্স না।

## Changelog
- **fix:** `PlayerView.surfaceType` রানটাইমে সেট করা যায় না (Media3-এর ডকুমেন্টেড লিমিটেশন) — এখন `res/layout/player_view_texture.xml`-এ `app:surface_type="texture_view"` দিয়ে inflate করা হয়।
- **fix:** Kotlin 2.0.21 + Compose BOM 2026.01.00 মিসম্যাচ ("internal in file" এরর) — Kotlin 2.2.20-এ আপগ্রেড করে ঠিক করার চেষ্টা হয়েছিল, কিন্তু 2.2.20-ও যথেষ্ট নতুন ছিল না, একই এরর থেকে গিয়েছিল। এখন Kotlin 2.4.10 (আসল বর্তমান স্টেবল) + KSP 2.3.10 দিয়ে ঠিক করা হয়েছে।
- **fix:** Hilt 2.56 → 2.58 (Kotlin 2.3+/2.4.10 metadata পড়তে সমস্যা হতো পুরনো Hiltে)।
- **fix:** KSP 2.3.10-এর নিজের রিকোয়ারমেন্ট অনুযায়ী AGP 8.9.1 → 8.10.0।
- **fix:** `android.kotlinOptions { jvmTarget = "17" }` Kotlin 2.4.10-এ hard error দিচ্ছিল — নতুন `kotlin.compilerOptions { jvmTarget = JvmTarget.JVM_17 }` DSL-এ মাইগ্রেট করা হয়েছে।
- **fix (আসল root cause):** `PlayerControls.kt`-এ `import androidx.compose.foundation.layout.weight` — এই লাইনটাই ছিল "internal in file" এররের আসল কারণ, তিনটা Kotlin ভার্সন বদলেও এরর যায়নি কারণ এটা ভার্সন সমস্যা ছিলই না। `weight` একটা `RowScope`/`ColumnScope` মেম্বার এক্সটেনশন, `Row{}`/`Column{}`-এর ভেতরে এমনিতেই available, import করার দরকার নেই। এই ভুল import লাইন মুছে ফেলা হয়েছে।
- **major:** ইঞ্জিন Media3/ExoPlayer থেকে libmpv-তে সুইচ করা হয়েছে (দেখো "ইঞ্জিন পরিবর্তন" সেকশন)। `PlayerViewModel`, `PlayerScreen`, `AudioFocusController`, `AppModule` — সবগুলো নতুন করে লেখা হয়েছে। `PlayerControls.kt`/`SettingsSheet.kt` অপরিবর্তিত (ViewModel-এর StateFlow শেপ ইচ্ছাকৃতভাবে একই রাখা হয়েছে)।
- **fix (কালো স্ক্রিন):** প্রথম সফল বিল্ডে অডিও/টাইমলাইন কাজ করছিল কিন্তু ভিডিও ফ্রেম দেখা যাচ্ছিল না। কারণ: `setVo("gpu")` কল বাদ পড়ে গিয়েছিল `initOptions()`-এ — এটা ছাড়া mpv ডিকোড করা ফ্রেম কোথায় রেন্ডার করবে জানত না। mpvRex-এর real কোড আবার মিলিয়ে এই লাইনটা যোগ করা হয়েছে।
- **debug:** `setVo` যোগ করার পরও প্রথম রিপোর্টে কালো স্ক্রিন মনে হয়েছিল। সরাসরি প্রমাণ দেখার জন্য একটা সাময়িক DEBUG ওভারলে যোগ করা হয়েছিল (vo-configured, hwdec-current, video track id)। টেস্টে কনফার্ম হয়েছে **ভিডিও আসলে ঠিকমতোই চলছিল** (`vo-configured: true`, `hwdec-current: mediacodec`, হার্ডওয়্যার ডিকোড কাজ করছে) — তাই DEBUG ওভারলে এখন সরিয়ে ফেলা হয়েছে।

## Feature batch: জেস্চার + থিম পলিশ + সাইনিং কী
(ফাইল এক্সপ্লোরার/মিডিয়া লাইব্রেরি ইচ্ছাকৃতভাবে বাদ — Room DB + নেভিগেশন লাগবে যেটা এখনো নেই, আলাদা রাউন্ডে করা হবে যাতে এই বিল্ড স্থির থাকে)

- **জেস্চার:** ডাবল-ট্যাপ (বাম/ডান তৃতীয়াংশ) = ±১০ সেকেন্ড সিক, মাঝে ডাবল-ট্যাপ = প্লে/পজ। উপর-নিচ সোয়াইপ: বাম অর্ধেক = ব্রাইটনেস, ডান অর্ধেক = ভলিউম। প্রতিটার সাথে একটা ছোট ফিডব্যাক বাবল দেখায়। *নোট: single-tap + double-tap একসাথে ডিটেক্ট করতে Compose-এর নিজস্ব ~300ms ওয়েট টাইম লাগে (সব ভিডিও প্লেয়ারেই এমন হয়, এটা বাগ না)।*
- **থিম পলিশ:** কন্ট্রোল প্যানেলে flat ব্যাকগ্রাউন্ডের বদলে গ্লাসমরফিক গ্র্যাডিয়েন্ট + rounded top corners, কন্ট্রোল দেখা/লুকানো এখন animated fade। Deprecated icon warning (VolumeUp/VolumeOff) ঠিক করে AutoMirrored ভার্সনে আপডেট করা হয়েছে (আগের বিল্ড লগেই এই deprecation warning ছিল)।
- **সাইনিং কী:** আসল release keystore বানানো হয়েছে (keytool দিয়ে, ২০৫৩ পর্যন্ত ভ্যালিড)। `app/build.gradle.kts`-এ signing config যোগ হয়েছে যেটা env var থেকে পড়ে (কখনো হার্ডকোড না) — GitHub Secrets সেটআপ করলে signed release APK বিল্ড হবে (দেখো "APK Signing" সেকশন)। keystore ফাইল repo-র বাইরে আলাদাভাবে দেওয়া হয়েছে, কখনো কমিট করা হয়নি।
- **change:** সব UI টেক্সট বাংলা থেকে ইংরেজিতে পরিবর্তন করা হয়েছে (Settings sheet, empty state) — ইউজারের অনুরোধ অনুযায়ী।
- **fix:** `BaseMPVView` abstract — `initOptions()`, `observeProperties()`, `postInitOptions()` ছাড়া কম্পাইলই হতো না। mpvRex-এর real `MPVView.kt` দেখে verify করে বাস্তবায়ন করা হয়েছে (`hwdec = "mediacodec,no"` — এটাই AV1-এ হার্ডওয়্যার না থাকলে সফটওয়্যার ফলব্যাক দেয়)। `observeProperty()` কলগুলো ViewModel থেকে সরিয়ে `SJMpvView.observeProperties()`-এ আনা হয়েছে, যেহেতু `BaseMPVView` নিজেই এটা সঠিক সময়ে কল করে।
- **fix:** Hilt-এর ভেতরের `kotlin-metadata-jvm` Kotlin 2.4.0 মেটাডেটা ফরম্যাট পড়তে পারছিল না ("maximum supported version is 2.3.0")। Hilt-এর লেটেস্ট ভার্সন (2.59.2) পর্যন্ত এই বাগ unresolved (google/dagger#5190) — তাই Hilt বাড়িয়ে লাভ নেই। এর বদলে Dagger 2.57+ থেকে unshaded হওয়া `kotlin-metadata-jvm` লাইব্রেরিকে সরাসরি আমাদের Kotlin ভার্সনের (2.4.10) সাথে ম্যাচ করিয়ে force করা হয়েছিল — কিন্তু এটাও কাজ করেনি (আসল ফেইলিং কোডপাথ Dagger-এর ভেতরে shaded, বাইরে থেকে override করা যায় না)। **চূড়ান্ত সমাধান:** Kotlin 2.4.10 → 2.3.10-এ নামানো হয়েছে (Kotlin-এর নিজের ডকুমেন্টেশন অনুযায়ী "AGP 8.x + Kotlin 2.3.10" অফিসিয়াল রেকমেন্ডেড পেয়ারিং), যেটার metadata format Hilt 2.58 native ভাবেই সাপোর্ট করে — কোনো হ্যাক লাগে না।

## Feature batch: মিডিয়া লাইব্রেরি + Navigation
- **নতুন:** `LibraryScreen` — MediaStore থেকে ডিভাইসের সব ভিডিও কুয়েরি করে গ্রিড ভিউতে দেখায় (থাম্বনেইল `MediaMetadataRetriever` দিয়ে, কোনো এক্সট্রা ইমেজ-লোডিং লাইব্রেরি ছাড়াই)। Newest/Name/Duration অনুযায়ী সর্ট।
- **নতুন:** `WatchStateEntity` (Room) — প্রতিটা ভিডিওর শেষ পজিশন আর watched স্ট্যাটাস ট্র্যাক করে (৫ সেকেন্ড পরপর + পজ করলে সেভ হয়), গ্রিডে progress bar/checkmark হিসেবে দেখায়।
- **নতুন:** Navigation Compose দিয়ে দুটো স্ক্রিনের (Library ↔ Player) মধ্যে নেভিগেশন যোগ করা হয়েছে — আগে শুধু একটা স্ক্রিন ছিল। বাইরের অ্যাপ থেকে ভিডিও ওপেন করলে (VIEW/SEND intent) লাইব্রেরি স্কিপ করে সরাসরি প্লেয়ারে যাবে, আগের মতোই।
- **permission:** `READ_MEDIA_VIDEO` (API 33+) / `READ_EXTERNAL_STORAGE` (তার আগে) যোগ করা হয়েছে — অ্যাপ প্রথমবার লাইব্রেরি খুললে পারমিশন চাইবে।

## fix batch: build error + video crop
- **fix:** `PlayerScreen.kt`-এ `ArrowBack` আইকন "Unresolved reference" এরর দিচ্ছিল — fully-qualified path (`Icons.AutoMirrored.Filled.ArrowBack`) দিয়ে সরাসরি অ্যাক্সেস করা যায় না, এটা আসলে একটা আলাদা প্যাকেজের Kotlin extension property, নির্দিষ্ট `import` লাগে (PlayerControls.kt-এর VolumeUp/VolumeOff-এর মতোই)। import যোগ করে ঠিক করা হয়েছে।
- **fix (ভিডিও crop/zoom):** ডিভাইসে টেস্টে দেখা গেছে ভিডিও পুরো ফ্রেম দেখাচ্ছিল না, zoom/crop হয়ে যাচ্ছিল (scoreboard ফ্রেমের কিনারায় কাটা যাচ্ছিল)। mpvRex-এর real `VideoAspect.Fit` কোড দেখে কারণ পাওয়া গেছে ও ঠিক করা হয়েছে — `initOptions()`-এ এখন `panscan=0` আর `video-aspect-override=-1` এক্সপ্লিসিটলি সেট করা হয়, যেটা ফুল ফ্রেম letterbox mode নিশ্চিত করে (crop/zoom না)।
