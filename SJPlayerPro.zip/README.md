# SJ Player Pro

## GitHub-এ আপলোড করবে যেভাবে
1. এই পুরো `SJPlayerPro` ফোল্ডারটা zip করা আছে — GitHub-এ নতুন repo বানাও (নাম: `SJPlayerPro`)।
2. GitHub web editor / Acode দিয়ে সব ফাইল আপলোড করো, ফোল্ডার স্ট্রাকচার হুবহু রেখে (বিশেষ করে `.github/workflows/build.yml` পাথটা ঠিক রাখা জরুরি)।
3. পুশ করলেই GitHub Actions অটোমেটিক ট্রিগার হবে (Actions ট্যাবে দেখতে পারবে)।
4. বিল্ড শেষ হলে Actions run-এর নিচে "Artifacts" সেকশনে `SJPlayerPro-debug-apk` পাবে — ওখান থেকে APK ডাউনলোড করবে।

## ইঞ্জিন পরিবর্তন: Media3 → libmpv
mpvRex (একটা জনপ্রিয় ওপেন-সোর্স libmpv-ভিত্তিক প্লেয়ার) দেখার পর ইঞ্জিন বদলানো হয়েছে Media3/ExoPlayer থেকে **libmpv**-তে (`mpvRex-libmpv`, mpv-android-এর একটা maintained fork, প্রি-বিল্ট AAR হিসেবে)। কারণ:
- libmpv-এর ভেতরে FFmpeg বান্ডেল করা থাকে — AC-3/DTS/FLAC/WMA এমনিতেই কাজ করে, আলাদা NDK বিল্ড লাগে না।
- Galaxy A13 (Exynos 850)-এ AV1 হার্ডওয়্যার ডিকোডার নেই — libmpv-তে সফটওয়্যার AV1 ডিকোড পাথ এমনিতেই কাজ করবে।
- প্রি-বিল্ট AAR হিসেবে আসে, তাই GitHub Actions-এ NDK সেটআপ লাগছে না, আমাদের বিল্ড পাইপলাইন অক্ষুণ্ণ।
- compileSdk 36 / minSdk 26 — আমাদের প্রজেক্টের সাথে হুবহু মেলে।

**সততার সাথে বলা দরকার:** এটা প্রথমবার এই dependency দিয়ে বিল্ড করা হচ্ছে। API কল, প্যারামিটার, লাইফসাইকেল প্যাটার্ন সব mpvRex-এর real, working কোড থেকে ভেরিফাই করে লেখা হয়েছে (গেস না), কিন্তু নতুন native dependency-তে প্রথম বিল্ডে ছোটখাটো অপ্রত্যাশিত ইস্যু আসার সম্ভাবনা পুরোপুরি শূন্য না।

## কী কী কাজ করছে (v1)
- libmpv ইঞ্জিন — বিস্তৃত ফরম্যাট সাপোর্ট (H.264/H.265/AV1 সফটওয়্যার+হার্ডওয়্যার, AC-3, DTS, FLAC, WMA, MP3, AAC, Opus সহ প্রায় সবকিছু, যেহেতু FFmpeg বান্ডেল করা)
- কাস্টম কন্ট্রোল প্যানেল (Play/Pause/Seek/Volume/Mute) — আগের UI অপরিবর্তিত
- কল বা স্ক্রিন-শেয়ার চলাকালীন অডিও বিহেভিয়ার সেট করার সেটিংস (Mute / Duck / স্বাভাবিক) — এখন mpv-এর নিজস্ব `mute` প্রপার্টি ব্যবহার করে, আগের ম্যানুয়াল volume-save-restore থেকে বেশি নির্ভরযোগ্য
- ফাইল ম্যানেজার থেকে ভিডিও ওপেন করার ইন্টেন্ট সাপোর্ট + অ্যাপের ভেতর থেকে "ভিডিও বাছাই করুন" বাটন

## এখনো যা নেই (ইচ্ছাকৃতভাবে বাদ, mpvRex-এ আছে)
- জেস্চার লেয়ার (Circular double-tap seek, zoom/pan, subtitle drag/swipe) — এগুলো ইঞ্জিন-নিরপেক্ষ, পরের ধাপে UI লেয়ারে যোগ করা যাবে libmpv ছোঁয়া ছাড়াই।
- ফাইল এক্সপ্লোরার / মিডিয়া লাইব্রেরি (Room DB, ফোল্ডার ব্রাউজিং, M3U প্লেলিস্ট, watched/unwatched) — এটা একটা আলাদা, বড় সাবসিস্টেম, পরের ধাপে।
- নেটওয়ার্ক স্ট্রিমিং (SMB/WebDAV/FTP) — পরের ধাপে।
- HDR-to-SDR টোন ম্যাপিং, ফ্রেম-পারফেক্ট A-B লুপ — libmpv-এর অ্যাডভান্সড শেডার/রেন্ডারিং ফিচার, পরে যোগ করা যাবে যেহেতু এখন ইঞ্জিনটা libmpv-ই।
- Permanent APK signing key — এখন শুধু debug build হচ্ছে।

## Version Decisions (কেন এই ভার্সনগুলো)
| জিনিস | ভার্সন | কেন |
|---|---|---|
| AGP | 8.10.0 | KSP 2.3.10-এর এক্সপ্লিসিট মিনিমাম রিকোয়ারমেন্ট ("minimum supported AGP version is 8.10.0")। compileSdk 36 সাপোর্ট কনফার্মড, AGP9 এড়িয়ে |
| Gradle | 8.11.1 | AGP-এর মিনিমাম রিকোয়ারমেন্ট |
| Kotlin | 2.4.10 | বর্তমান আসল স্টেবল রিলিজ |
| KSP | 2.3.10 | Kotlin 2.4.10-এর সাথে kotlinlang.org-এর অফিসিয়াল ডকুমেন্টেড পেয়ারিং |
| Compose BOM | 2026.01.00 | compileSdk 37/AGP9 বাধ্যতামূলক হওয়ার আগের লেটেস্ট স্টেবল লাইন |
| libmpv | mpvRex-libmpv v0.0.8 | mpvRex (real, active, 340+ star প্রজেক্ট)-এর ব্যবহৃত exact ভার্সন, প্রি-বিল্ট AAR |
| Hilt | 2.58 | 2.59+ AGP9 বাধ্যতামূলক করেছে; 2.58 শেষ AGP8-কম্প্যাটিবল ভার্সন |
| compileSdk/targetSdk | 36 | mpvRex নিজেও এই একই compileSdk ব্যবহার করে |
| minSdk | 26 | legacy PNG launcher icon এড়াতে + mpvRex-এর নিজের minSdk-এর সাথেও মেলে |

বিল্ড ফেইল করলে এরর মেসেজ পুরোটা কপি করে পাঠিও — root cause ধরে ঠিক করে দেব, গেস-বেসড ফিক্স না।

## Changelog
- **fix:** `PlayerView.surfaceType` রানটাইমে সেট করা যায় না (Media3-এর ডকুমেন্টেড লিমিটেশন) — এখন `res/layout/player_view_texture.xml`-এ `app:surface_type="texture_view"` দিয়ে inflate করা হয়।
- **fix:** Kotlin 2.0.21 + Compose BOM 2026.01.00 মিসম্যাচ ("internal in file" এরর) — Kotlin 2.2.20-এ আপগ্রেড করে ঠিক করার চেষ্টা হয়েছিল, কিন্তু 2.2.20-ও যথেষ্ট নতুন ছিল না, একই এরর থেকে গিয়েছিল। এখন Kotlin 2.4.10 (আসল বর্তমান স্টেবল) + KSP 2.3.10 দিয়ে ঠিক করা হয়েছে।
- **fix:** Hilt 2.56 → 2.58 (Kotlin 2.3+/2.4.10 metadata পড়তে সমস্যা হতো পুরনো Hiltে)।
- **fix:** KSP 2.3.10-এর নিজের রিকোয়ারমেন্ট অনুযায়ী AGP 8.9.1 → 8.10.0।
- **fix:** `android.kotlinOptions { jvmTarget = "17" }` Kotlin 2.4.10-এ hard error দিচ্ছিল — নতুন `kotlin.compilerOptions { jvmTarget = JvmTarget.JVM_17 }` DSL-এ মাইগ্রেট করা হয়েছে।
- **fix (আসল root cause):** `PlayerControls.kt`-এ `import androidx.compose.foundation.layout.weight` — এই লাইনটাই ছিল "internal in file" এররের আসল কারণ, তিনটা Kotlin ভার্সন বদলেও এরর যায়নি কারণ এটা ভার্সন সমস্যা ছিলই না। `weight` একটা `RowScope`/`ColumnScope` মেম্বার এক্সটেনশন, `Row{}`/`Column{}`-এর ভেতরে এমনিতেই available, import করার দরকার নেই। এই ভুল import লাইন মুছে ফেলা হয়েছে।
- **major:** ইঞ্জিন Media3/ExoPlayer থেকে libmpv-তে সুইচ করা হয়েছে (দেখো "ইঞ্জিন পরিবর্তন" সেকশন)। `PlayerViewModel`, `PlayerScreen`, `AudioFocusController`, `AppModule` — সবগুলো নতুন করে লেখা হয়েছে। `PlayerControls.kt`/`SettingsSheet.kt` অপরিবর্তিত (ViewModel-এর StateFlow শেপ ইচ্ছাকৃতভাবে একই রাখা হয়েছে)।
