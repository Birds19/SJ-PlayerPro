# SJ Player Pro

## GitHub-এ আপলোড করবে যেভাবে
1. এই পুরো `SJPlayerPro` ফোল্ডারটা zip করা আছে — GitHub-এ নতুন repo বানাও (নাম: `SJPlayerPro`)।
2. GitHub web editor / Acode দিয়ে সব ফাইল আপলোড করো, ফোল্ডার স্ট্রাকচার হুবহু রেখে (বিশেষ করে `.github/workflows/build.yml` পাথটা ঠিক রাখা জরুরি)।
3. পুশ করলেই GitHub Actions অটোমেটিক ট্রিগার হবে (Actions ট্যাবে দেখতে পারবে)।
4. বিল্ড শেষ হলে Actions run-এর নিচে "Artifacts" সেকশনে `SJPlayerPro-debug-apk` পাবে — ওখান থেকে APK ডাউনলোড করবে।

## কী কী কাজ করছে (v1)
- H.264 / H.265 / AV1 (hardware, ডিভাইস সাপোর্ট করলে) / AAC / MP3 / FLAC / Opus / Vorbis — Media3-এর built-in ফরম্যাট
- TextureView-based রেন্ডারিং — স্ক্রিন শেয়ারে ব্ল্যাক স্ক্রিন হবে না
- কাস্টম কন্ট্রোল প্যানেল (Play/Pause/Seek/Volume/Mute)
- কল বা স্ক্রিন-শেয়ার চলাকালীন অডিও বিহেভিয়ার সেট করার সেটিংস (Mute / Duck / স্বাভাবিক)
- ফাইল ম্যানেজার থেকে ভিডিও ওপেন করার ইন্টেন্ট সাপোর্ট + অ্যাপের ভেতর থেকে "ভিডিও বাছাই করুন" বাটন

## এখনো যা নেই (ইচ্ছাকৃতভাবে বাদ)
- **FFmpeg (AC-3/DTS/WMA)** — কারণ ও রিজনিং চ্যাটে বলা আছে। যোগ করতে চাইলে বোলো, আলাদা ধাপে করব (NDK বিল্ড GitHub Actions-এ সেটআপ লাগবে)।
- Permanent APK signing key — এখন শুধু debug build হচ্ছে। Play Store বা পার্মানেন্ট ডিস্ট্রিবিউশনের জন্য লাগলে বোলো।

## Version Decisions (কেন এই ভার্সনগুলো)
| জিনিস | ভার্সন | কেন |
|---|---|---|
| AGP | 8.10.0 | KSP 2.3.10-এর এক্সপ্লিসিট মিনিমাম রিকোয়ারমেন্ট ("minimum supported AGP version is 8.10.0")। compileSdk 36 সাপোর্ট কনফার্মড, AGP9 এড়িয়ে |
| Gradle | 8.11.1 | AGP 8.9.1-এর মিনিমাম রিকোয়ারমেন্ট |
| Kotlin | 2.4.10 | বর্তমান আসল স্টেবল রিলিজ (2.2.20-ও পুরনো প্রমাণিত হয়েছিল - Compose BOM 2026.01.00-এর জন্য compiler লাইব্রেরির সমান বা নতুন হতে হয়) |
| KSP | 2.3.10 | Kotlin 2.4.10-এর সাথে kotlinlang.org-এর অফিসিয়াল ডকুমেন্টেড পেয়ারিং |
| Compose BOM | 2026.01.00 | compileSdk 37/AGP9 বাধ্যতামূলক হওয়ার আগের লেটেস্ট স্টেবল লাইন |
| Media3 | 1.10.0 | বর্তমান স্টেবল রিলিজ |
| Hilt | 2.58 | 2.59+ AGP9 বাধ্যতামূলক করেছে; 2.58 শেষ AGP8-কম্প্যাটিবল ভার্সন, আর এতে Kotlin 2.3+/2.4.10 metadata পড়ার ফিক্সও আছে |
| compileSdk/targetSdk | 36 | Media3 1.10.0-এর AAR metadata রিকোয়ারমেন্ট মেটাতে (Android 16) |
| minSdk | 26 | legacy PNG launcher icon এড়াতে (adaptive icon only) + AudioFocusRequest বিল্ডার ক্লিন কোড |

বিল্ড ফেইল করলে এরর মেসেজ পুরোটা কপি করে পাঠিও — root cause ধরে ঠিক করে দেব, গেস-বেসড ফিক্স না।

## Changelog
- **fix:** `PlayerView.surfaceType` রানটাইমে সেট করা যায় না (Media3-এর ডকুমেন্টেড লিমিটেশন) — এখন `res/layout/player_view_texture.xml`-এ `app:surface_type="texture_view"` দিয়ে inflate করা হয়।
- **fix:** Kotlin 2.0.21 + Compose BOM 2026.01.00 মিসম্যাচ ("internal in file" এরর) — Kotlin 2.2.20-এ আপগ্রেড করে ঠিক করার চেষ্টা হয়েছিল, কিন্তু 2.2.20-ও যথেষ্ট নতুন ছিল না, একই এরর থেকে গিয়েছিল। এখন Kotlin 2.4.10 (আসল বর্তমান স্টেবল) + KSP 2.3.10 দিয়ে ঠিক করা হয়েছে।
- **fix:** Hilt 2.56 → 2.58 (Kotlin 2.3+/2.4.10 metadata পড়তে সমস্যা হতো পুরনো Hiltে)।
- **fix:** KSP 2.3.10-এর নিজের রিকোয়ারমেন্ট অনুযায়ী AGP 8.9.1 → 8.10.0।
- **fix:** `android.kotlinOptions { jvmTarget = "17" }` Kotlin 2.4.10-এ hard error দিচ্ছিল — নতুন `kotlin.compilerOptions { jvmTarget = JvmTarget.JVM_17 }` DSL-এ মাইগ্রেট করা হয়েছে।
- **fix (আসল root cause):** `PlayerControls.kt`-এ `import androidx.compose.foundation.layout.weight` — এই লাইনটাই ছিল "internal in file" এররের আসল কারণ, তিনটা Kotlin ভার্সন বদলেও এরর যায়নি কারণ এটা ভার্সন সমস্যা ছিলই না। `weight` একটা `RowScope`/`ColumnScope` মেম্বার এক্সটেনশন, `Row{}`/`Column{}`-এর ভেতরে এমনিতেই available, import করার দরকার নেই। এই ভুল import লাইন মুছে ফেলা হয়েছে।
