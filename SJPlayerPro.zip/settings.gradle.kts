pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // libmpv prebuilt AAR (verified working dependency of mpvRex, a fork of mpv-android)
        maven(url = "https://sfsakhawat999.github.io/mpvRex-libmpv")
        maven(url = "https://www.jitpack.io") {
            content {
                includeGroup("com.github.sfsakhawat999")
            }
        }
    }
}
rootProject.name = "SJPlayerPro"
include(":app")
