import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
    id("com.google.dagger.hilt.android")
}

android {
    namespace = "com.sj.playerpro"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.sj.playerpro"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
        // Required for libmpv's native .so files to load correctly at runtime
        // (verified from mpvRex's own app/build.gradle.kts) - without this,
        // the build succeeds but the app crashes with UnsatisfiedLinkError.
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

// android.kotlinOptions{} is a hard compile error as of Kotlin 2.4.10
// ("Using 'jvmTarget: String' is an error. Please migrate to the
// compilerOptions DSL") - this is the current, official replacement per
// developer.android.com/build/migrate-to-built-in-kotlin.
kotlin {
    compilerOptions {
        jvmTarget = JvmTarget.JVM_17
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")

    implementation(platform("androidx.compose:compose-bom:2026.01.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // libmpv (via mpvRex-libmpv, a maintained fork of mpv-android) - replaces
    // Media3/ExoPlayer as the playback engine. Bundles FFmpeg internally, so:
    // - AC-3/DTS/FLAC/WMA work out of the box (no separate decoder extension needed)
    // - AV1 gets a working software decode path even without hardware AV1
    //   support (relevant on Exynos 850 / Galaxy A13)
    // Verified against the actual mpvRex source before writing PlayerViewModel/
    // PlayerScreen: BaseMPVView.playFile(String) handles content:// URIs itself.
    implementation("com.github.sfsakhawat999:mpvRex-libmpv:v0.0.8")

    implementation("com.google.dagger:hilt-android:2.58")
    ksp("com.google.dagger:hilt-android-compiler:2.58")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2026.01.00"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
