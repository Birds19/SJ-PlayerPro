# Add project specific ProGuard rules here.
# minifyEnabled is currently false (see app/build.gradle.kts) so these
# rules are inert for now, kept here ready for when release minification
# is turned on later.
