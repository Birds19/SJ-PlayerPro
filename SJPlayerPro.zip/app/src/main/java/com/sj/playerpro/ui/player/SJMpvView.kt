package com.sj.playerpro.ui.player

import android.content.Context
import android.util.AttributeSet
import `is`.xyz.mpv.BaseMPVView
import `is`.xyz.mpv.MPVLib

/**
 * Thin wrapper around BaseMPVView (from the mpvRex-libmpv / mpv-android
 * library). BaseMPVView needs an (Context, AttributeSet) constructor to be
 * inflatable from XML - see res/layout/mpv_view.xml - which is how it's
 * created in PlayerScreen.kt (mirrors how mpvRex itself instantiates it,
 * verified against their MPVView.kt).
 *
 * BaseMPVView is abstract with three required hooks (confirmed by the
 * compiler, then cross-checked against mpvRex's real MPVView.kt so these
 * aren't guessed):
 *   - initOptions(): mpv options that must be set before native init.
 *   - observeProperties(): called internally by BaseMPVView at the correct
 *     point after init - this is why property observation lives HERE and
 *     not in PlayerViewModel (an earlier version wrongly called
 *     MPVLib.observeProperty from the ViewModel instead).
 *   - postInitOptions(): post-init tweaks; empty for our v1 scope (mpvRex
 *     uses it for debanding/stats-page, which we don't have yet).
 *
 * [ensureInitialized] guards against calling BaseMPVView.initialize() more
 * than once on the same instance, which mpvRex's own changelog flags as a
 * real crash source ("Native Teardown Crash") - cheap insurance since we
 * can't directly inspect BaseMPVView's internals (it's a compiled AAR).
 */
class SJMpvView(
    context: Context,
    attrs: AttributeSet,
) : BaseMPVView(context, attrs) {

    private var isInitialized = false

    fun ensureInitialized() {
        if (isInitialized) return
        initialize(context.filesDir.path, context.cacheDir.path)
        isInitialized = true
    }

    override fun initOptions() {
        // CRITICAL: without this, mpv decodes audio and tracks position/duration
        // fine (which is why those appeared to work) but has no video render
        // target configured, so frames are decoded and silently discarded -
        // black screen. Confirmed by cross-checking mpvRex's real initOptions(),
        // where this line was present and I had originally missed it.
        setVo("gpu")

        // hwdec fallback order: try MediaCodec hardware decode first, fall
        // back to software (libmpv's bundled FFmpeg) automatically per-codec.
        // This is what gives working AV1 playback on devices with no AV1
        // hardware decoder (e.g. Exynos 850 / Galaxy A13) without any extra
        // code on our side - mpv just falls back to software decode for AV1
        // while still using hardware for H.264/H.265.
        MPVLib.setOptionString("hwdec", "mediacodec,no")
        MPVLib.setOptionString("hwdec-codecs", "all")

        // Don't tear down the native player when a file finishes - keeps
        // SJMpvView valid so the "pick another video" flow keeps working.
        MPVLib.setPropertyBoolean("keep-open", true)
        MPVLib.setPropertyBoolean("input-default-bindings", true)

        // Precise (frame-accurate) seeking for our seek bar.
        MPVLib.setOptionString("hr-seek", "yes")
    }

    override fun observeProperties() {
        MPVLib.observeProperty("pause", MPVLib.MpvFormat.MPV_FORMAT_FLAG)
        MPVLib.observeProperty("time-pos", MPVLib.MpvFormat.MPV_FORMAT_DOUBLE)
        MPVLib.observeProperty("duration", MPVLib.MpvFormat.MPV_FORMAT_DOUBLE)
        MPVLib.observeProperty("volume", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        MPVLib.observeProperty("mute", MPVLib.MpvFormat.MPV_FORMAT_FLAG)
    }

    override fun postInitOptions() {
        // Intentionally empty for v1 - mpvRex uses this for debanding/stats
        // preferences we don't have a settings UI for yet.
    }
}

