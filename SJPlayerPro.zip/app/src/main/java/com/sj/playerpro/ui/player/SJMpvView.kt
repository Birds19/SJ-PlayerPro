package com.sj.playerpro.ui.player

import android.content.Context
import android.util.AttributeSet
import `is`.xyz.mpv.BaseMPVView

/**
 * Thin wrapper around BaseMPVView (from the mpvRex-libmpv / mpv-android
 * library). BaseMPVView needs an (Context, AttributeSet) constructor to be
 * inflatable from XML - see res/layout/mpv_view.xml - which is how it's
 * created in PlayerScreen.kt (mirrors how mpvRex itself instantiates it,
 * verified against their MPVView.kt).
 *
 * [ensureInitialized] guards against calling BaseMPVView.initialize() more
 * than once on the same instance, which mpvRex's own changelog flags as a
 * real crash source ("Native Teardown Crash") - cheap insurance since we
 * can't directly inspect BaseMPVView's internals (it's a compiled AAR).
 */
class SJMpvView(
    context: Context,
    attrs: AttributeSet,
) : BaseMPVView(context, attrs) {

    private var isInitialized = false

    fun ensureInitialized() {
        if (isInitialized) return
        initialize(context.filesDir.path, context.cacheDir.path)
        isInitialized = true
    }
}
