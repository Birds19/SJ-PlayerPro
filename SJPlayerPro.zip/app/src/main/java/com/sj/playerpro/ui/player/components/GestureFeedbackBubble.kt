package com.sj.playerpro.ui.player.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Small translucent pill showing transient feedback (seek jump, volume %,
 * brightness %) during gestures. [text] == null hides it (animated).
 */
@Composable
fun GestureFeedbackBubble(
    text: String?,
    alignment: Alignment,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = text != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(alignment).padding(28.dp)
        ) {
            Box(
                modifier = Modifier
                    .background(Color(0xAA000000), RoundedCornerShape(14.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text(text ?: "", color = Color.White, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
