package com.sj.playerpro.ui.player.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sj.playerpro.model.FocusLossBehaviour

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    currentBehaviour: FocusLossBehaviour,
    onBehaviourSelected: (FocusLossBehaviour) -> Unit,
    onDismiss: () -> Unit
) {
    var selected by remember { mutableStateOf(currentBehaviour) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Text("কল / স্ক্রিন শেয়ারিং চলাকালীন অডিও", style = MaterialTheme.typography.titleMedium)

            Spacer(modifier = Modifier.height(16.dp))

            FocusLossBehaviour.entries.forEach { behaviour ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    RadioButton(selected = selected == behaviour, onClick = { selected = behaviour })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (behaviour) {
                            FocusLossBehaviour.MUTE -> "ভিডিও অডিও মিউট হবে"
                            FocusLossBehaviour.DUCK -> "ভলিউম কমে যাবে (ডাক)"
                            FocusLossBehaviour.NONE -> "স্বাভাবিকভাবে চলতে থাকবে"
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { onBehaviourSelected(selected); onDismiss() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("প্রয়োগ করুন")
            }
        }
    }
}
