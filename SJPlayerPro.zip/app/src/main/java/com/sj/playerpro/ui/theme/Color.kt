package com.sj.playerpro.ui.theme

import androidx.compose.ui.graphics.Color

val AccentCyan = Color(0xFF00E5FF)
val AccentCyanDim = Color(0xFF0097A7)
val SurfaceDark = Color(0xFF0D1117)
val SurfaceDarkVariant = Color(0xFF161B22)
