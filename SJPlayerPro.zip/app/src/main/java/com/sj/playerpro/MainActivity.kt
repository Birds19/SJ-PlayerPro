package com.sj.playerpro

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sj.playerpro.ui.library.LibraryScreen
import com.sj.playerpro.ui.player.PlayerScreen
import com.sj.playerpro.ui.theme.SJPlayerProTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val videoUriFromIntent: Uri? = resolveIntentUri(intent)

        setContent {
            SJPlayerProTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        // If the app was opened directly with a video (from another
                        // app's "open with" / share), skip the library and jump
                        // straight into playback - matches the pre-library behaviour.
                        startDestination = if (videoUriFromIntent != null) "player_direct" else "library"
                    ) {
                        composable("library") {
                            LibraryScreen(
                                onVideoClick = { video ->
                                    val encoded = Uri.encode(video.uri.toString())
                                    navController.navigate("player/$encoded")
                                },
                                onOpenPlayerWithoutVideo = {
                                    navController.navigate("player")
                                }
                            )
                        }
                        composable("player_direct") {
                            PlayerScreen(initialUri = videoUriFromIntent)
                        }
                        composable("player") {
                            PlayerScreen(
                                initialUri = null,
                                onBackClick = { navController.popBackStack() }
                            )
                        }
                        composable(
                            route = "player/{uri}",
                            arguments = listOf(navArgument("uri") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val encoded = backStackEntry.arguments?.getString("uri")
                            val uri = encoded?.let { Uri.parse(Uri.decode(it)) }
                            PlayerScreen(
                                initialUri = uri,
                                onBackClick = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun resolveIntentUri(intent: Intent?): Uri? {
        return when (intent?.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_STREAM)
                }
            }
            else -> null
        }
    }
}
