package com.sj.playerpro.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [WatchStateEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchStateDao(): WatchStateDao
}
