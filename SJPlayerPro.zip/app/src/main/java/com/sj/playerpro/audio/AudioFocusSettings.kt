package com.sj.playerpro.audio

import com.sj.playerpro.model.FocusLossBehaviour
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Simple app-wide holder for the user's chosen behaviour when audio focus is
 * lost (e.g. an incoming call, screen sharing, another app playing audio).
 * Read by [AudioFocusController], written by the Settings sheet.
 */
object AudioFocusSettings {
    val focusLossBehaviour = MutableStateFlow(FocusLossBehaviour.MUTE)
}
