package com.sj.playerpro.ui.library

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sj.playerpro.data.MediaStoreRepository
import com.sj.playerpro.data.VideoItem
import com.sj.playerpro.data.VideoSortOrder
import com.sj.playerpro.data.WatchStateDao
import com.sj.playerpro.data.WatchStateEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val application: Application,
    private val mediaStoreRepository: MediaStoreRepository,
    private val watchStateDao: WatchStateDao
) : ViewModel() {

    private val _rawVideos = MutableStateFlow<List<VideoItem>>(emptyList())
    private val _sortOrder = MutableStateFlow(VideoSortOrder.DATE_NEWEST)
    val sortOrder: StateFlow<VideoSortOrder> = _sortOrder

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _hasPermission = MutableStateFlow(false)
    val hasPermission: StateFlow<Boolean> = _hasPermission

    private val thumbnailCache = mutableMapOf<Uri, Bitmap?>()

    val watchStates: StateFlow<Map<String, WatchStateEntity>> =
        watchStateDao.observeAll()
            .map { list -> list.associateBy { it.videoUriString } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val videos: StateFlow<List<VideoItem>> = combine(_rawVideos, _sortOrder) { list, order ->
        when (order) {
            VideoSortOrder.DATE_NEWEST -> list.sortedByDescending { it.dateAddedSec }
            VideoSortOrder.NAME_A_Z -> list.sortedBy { it.name.lowercase() }
            VideoSortOrder.DURATION_LONGEST -> list.sortedByDescending { it.durationMs }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun onPermissionResult(granted: Boolean) {
        _hasPermission.value = granted
        if (granted) refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _isLoading.value = true
            _rawVideos.value = mediaStoreRepository.queryVideos(application)
            _isLoading.value = false
        }
    }

    fun setSortOrder(order: VideoSortOrder) {
        _sortOrder.value = order
    }

    suspend fun getThumbnail(item: VideoItem): Bitmap? {
        if (thumbnailCache.containsKey(item.uri)) return thumbnailCache[item.uri]
        val bmp = mediaStoreRepository.getThumbnail(application, item)
        thumbnailCache[item.uri] = bmp
        return bmp
    }
}
