package com.sj.playerpro.ui.library

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import com.sj.playerpro.data.VideoItem
import com.sj.playerpro.data.VideoSortOrder
import com.sj.playerpro.ui.library.components.VideoGridItem

private fun mediaPermissionName(): String =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

@Composable
fun LibraryScreen(
    onVideoClick: (VideoItem) -> Unit,
    onOpenPlayerWithoutVideo: () -> Unit,
    viewModel: LibraryViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val videos by viewModel.videos.collectAsState()
    val watchStates by viewModel.watchStates.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val hasPermission by viewModel.hasPermission.collectAsState()

    var showSortMenu by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted -> viewModel.onPermissionResult(granted) }

    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(
            context, mediaPermissionName()
        ) == PackageManager.PERMISSION_GRANTED
        viewModel.onPermissionResult(granted)
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0D1117))) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Library", style = MaterialTheme.typography.headlineSmall, color = Color.White)
            Box {
                IconButton(onClick = { showSortMenu = true }) {
                    Icon(Icons.Default.Sort, contentDescription = "Sort", tint = Color.White)
                }
                DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("Newest first") },
                        onClick = { viewModel.setSortOrder(VideoSortOrder.DATE_NEWEST); showSortMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Name (A-Z)") },
                        onClick = { viewModel.setSortOrder(VideoSortOrder.NAME_A_Z); showSortMenu = false }
                    )
                    DropdownMenuItem(
                        text = { Text("Longest first") },
                        onClick = { viewModel.setSortOrder(VideoSortOrder.DURATION_LONGEST); showSortMenu = false }
                    )
                }
            }
        }

        when {
            !hasPermission -> PermissionPrompt(
                onGrantClick = { permissionLauncher.launch(mediaPermissionName()) },
                onOpenPlayerWithoutVideo = onOpenPlayerWithoutVideo
            )
            isLoading && videos.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color(0xFF00E5FF))
            }
            videos.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No videos found on this device", color = Color.White)
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(videos, key = { it.uri.toString() }) { item ->
                    val state = watchStates[item.uri.toString()]
                    val progressFraction = state?.let {
                        if (it.durationMs > 0) it.lastPositionMs.toFloat() / it.durationMs else null
                    }
                    VideoGridItem(
                        item = item,
                        progressFraction = progressFraction,
                        isWatched = state?.isWatched == true,
                        loadThumbnail = { viewModel.getThumbnail(item) },
                        onClick = { onVideoClick(item) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionPrompt(
    onGrantClick: () -> Unit,
    onOpenPlayerWithoutVideo: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "SJ Player Pro needs permission to see the videos on your device",
            color = Color.White,
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(modifier = Modifier.padding(8.dp))
        Button(onClick = onGrantClick) { Text("Grant permission") }
        Spacer(modifier = Modifier.padding(4.dp))
        Text(
            "or open a single video without the library",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 12.dp)
        )
        Button(onClick = onOpenPlayerWithoutVideo) { Text("Open a video") }
    }
}
