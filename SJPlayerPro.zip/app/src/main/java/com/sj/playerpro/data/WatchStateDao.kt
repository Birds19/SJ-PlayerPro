package com.sj.playerpro.data

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface WatchStateDao {

    @Query("SELECT * FROM watch_state")
    fun observeAll(): Flow<List<WatchStateEntity>>

    @Query("SELECT * FROM watch_state WHERE videoUriString = :uriString")
    suspend fun get(uriString: String): WatchStateEntity?

    @Upsert
    suspend fun upsert(state: WatchStateEntity)
}
