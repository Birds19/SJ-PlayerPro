package com.sj.playerpro.model

enum class FocusLossBehaviour {
    MUTE,
    DUCK,
    NONE
}
