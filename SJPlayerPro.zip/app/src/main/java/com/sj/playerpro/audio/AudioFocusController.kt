package com.sj.playerpro.audio

import android.content.Context
import android.media.AudioAttributes as PlatformAudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import androidx.media3.exoplayer.ExoPlayer
import com.sj.playerpro.model.FocusLossBehaviour
import kotlinx.coroutines.flow.StateFlow

/**
 * Handles Android's real audio-focus system (android.media.AudioManager /
 * AudioFocusRequest) directly, instead of relying on Media3's built-in
 * automatic focus handling.
 *
 * WHY THIS APPROACH: Media3's ExoPlayer.Builder has no public API to plug in
 * custom "don't pause, just duck/mute" behaviour - its built-in focus
 * handling (handleAudioFocus = true) will pause playback on focus loss,
 * which is exactly what we don't want (video should keep playing silently
 * or ducked during a call / screen share).
 *
 * So: ExoPlayer is created with handleAudioFocus = false (see AppModule.kt),
 * and this class owns the AudioFocusRequest lifecycle and volume changes
 * itself, using the real, documented android.media API.
 */
class AudioFocusController(
    context: Context,
    private val audioManager: AudioManager,
    private val behaviourFlow: StateFlow<FocusLossBehaviour>
) {
    // context param kept for API symmetry / future use (e.g. requesting focus
    // scoped to a specific AudioDeviceInfo down the line); not directly used yet.
    private var player: ExoPlayer? = null
    private var savedVolume = 1f
    private var focusRequest: AudioFocusRequest? = null

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        val exoPlayer = player ?: return@OnAudioFocusChangeListener
        val behaviour = behaviourFlow.value

        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                when (behaviour) {
                    FocusLossBehaviour.MUTE -> {
                        savedVolume = exoPlayer.volume
                        exoPlayer.volume = 0f
                    }
                    FocusLossBehaviour.DUCK -> {
                        savedVolume = exoPlayer.volume
                        exoPlayer.volume = 0.2f
                    }
                    FocusLossBehaviour.NONE -> {
                        // ইচ্ছাকৃতভাবে কিছু করা হচ্ছে না - ভিডিও পূর্ণ ভলিউমে চলতেই থাকবে
                    }
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                if (behaviour != FocusLossBehaviour.NONE) {
                    savedVolume = exoPlayer.volume
                    exoPlayer.volume = 0.2f
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                exoPlayer.volume = savedVolume
            }
        }
    }

    fun attachPlayer(exoPlayer: ExoPlayer) {
        player = exoPlayer
        savedVolume = exoPlayer.volume
    }

    fun requestFocus() {
        val attributes = PlatformAudioAttributes.Builder()
            .setUsage(PlatformAudioAttributes.USAGE_MEDIA)
            .setContentType(PlatformAudioAttributes.CONTENT_TYPE_MOVIE)
            .build()

        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attributes)
            .setOnAudioFocusChangeListener(focusChangeListener)
            .setWillPauseWhenDucked(false)
            .build()

        focusRequest = request
        audioManager.requestAudioFocus(request)
    }

    fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
    }
}
