package com.sj.playerpro.audio

import android.content.Context
import android.media.AudioAttributes as PlatformAudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import `is`.xyz.mpv.MPVLib
import com.sj.playerpro.model.FocusLossBehaviour
import kotlinx.coroutines.flow.StateFlow

/**
 * Handles Android's real audio-focus system (android.media.AudioManager /
 * AudioFocusRequest) and, on change, adjusts mpv's own volume/pause state
 * directly via MPVLib - there's no "player" object to attach to anymore
 * (MPVLib is a static, process-wide bridge), which actually simplifies this
 * class compared to the old Media3 version.
 *
 * All MPVLib calls are wrapped in runCatching: if focus changes before the
 * native player is initialized (e.g. very early in the Activity lifecycle),
 * this must not crash - mirrors a defensive pattern used in mpvRex's own
 * source (they wrap MPVLib calls the same way in several places).
 */
class AudioFocusController(
    context: Context,
    private val audioManager: AudioManager,
    private val behaviourFlow: StateFlow<FocusLossBehaviour>
) {
    private var savedVolumePercent = 100
    private var focusRequest: AudioFocusRequest? = null

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        val behaviour = behaviourFlow.value

        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                when (behaviour) {
                    FocusLossBehaviour.MUTE -> {
                        runCatching { MPVLib.setPropertyBoolean("mute", true) }
                    }
                    FocusLossBehaviour.DUCK -> {
                        runCatching {
                            savedVolumePercent = MPVLib.getPropertyInt("volume") ?: 100
                            MPVLib.setPropertyInt("volume", 20)
                        }
                    }
                    FocusLossBehaviour.NONE -> {
                        // ইচ্ছাকৃতভাবে কিছু করা হচ্ছে না - ভিডিও পূর্ণ ভলিউমে চলতেই থাকবে
                    }
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                if (behaviour != FocusLossBehaviour.NONE) {
                    runCatching {
                        savedVolumePercent = MPVLib.getPropertyInt("volume") ?: 100
                        MPVLib.setPropertyInt("volume", 20)
                    }
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                runCatching {
                    MPVLib.setPropertyBoolean("mute", false)
                    MPVLib.setPropertyInt("volume", savedVolumePercent)
                }
            }
        }
    }

    fun requestFocus() {
        val attributes = PlatformAudioAttributes.Builder()
            .setUsage(PlatformAudioAttributes.USAGE_MEDIA)
            .setContentType(PlatformAudioAttributes.CONTENT_TYPE_MOVIE)
            .build()

        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attributes)
            .setOnAudioFocusChangeListener(focusChangeListener)
            .setWillPauseWhenDucked(false)
            .build()

        focusRequest = request
        audioManager.requestAudioFocus(request)
    }

    fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
    }
}
