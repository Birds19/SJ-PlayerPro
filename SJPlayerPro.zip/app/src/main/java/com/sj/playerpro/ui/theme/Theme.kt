package com.sj.playerpro.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val PlayerDarkColorScheme = darkColorScheme(
    primary = AccentCyan,
    secondary = AccentCyanDim,
    background = SurfaceDark,
    surface = SurfaceDarkVariant
)

@Composable
fun SJPlayerProTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = SurfaceDark.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = PlayerDarkColorScheme,
        typography = Typography,
        content = content
    )
}
