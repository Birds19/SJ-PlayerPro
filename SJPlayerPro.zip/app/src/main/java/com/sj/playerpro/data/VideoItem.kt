package com.sj.playerpro.data

import android.net.Uri

/**
 * A single video as read from MediaStore. Not persisted ourselves - MediaStore
 * is the source of truth for what videos exist; Room ([WatchStateEntity]) only
 * stores our own per-video watch progress on top of that.
 */
data class VideoItem(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAddedSec: Long
)

enum class VideoSortOrder {
    DATE_NEWEST,
    NAME_A_Z,
    DURATION_LONGEST
}
