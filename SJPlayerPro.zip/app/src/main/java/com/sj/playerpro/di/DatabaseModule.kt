package com.sj.playerpro.di

import android.app.Application
import androidx.room.Room
import com.sj.playerpro.data.AppDatabase
import com.sj.playerpro.data.WatchStateDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(app: Application): AppDatabase =
        Room.databaseBuilder(app, AppDatabase::class.java, "sj-player-pro.db").build()

    @Provides
    @Singleton
    fun provideWatchStateDao(database: AppDatabase): WatchStateDao = database.watchStateDao()
}
