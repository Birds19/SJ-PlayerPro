package com.sj.playerpro.ui.player

import android.net.Uri
import android.view.LayoutInflater
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.ui.PlayerView
import com.sj.playerpro.R
import com.sj.playerpro.ui.player.components.PlayerControls
import com.sj.playerpro.ui.player.components.SettingsSheet

@Composable
fun PlayerScreen(
    initialUri: Uri? = null,
    viewModel: PlayerViewModel = hiltViewModel()
) {
    val player = viewModel.player
    val isPlaying by viewModel.isPlaying.collectAsState()
    val hasMedia by viewModel.hasMedia.collectAsState()
    val currentPos by viewModel.currentPositionMs.collectAsState()
    val duration by viewModel.durationMs.collectAsState()
    val volume by viewModel.volume.collectAsState()
    val isMuted by viewModel.isMuted.collectAsState()
    val focusBehaviour by viewModel.focusLossBehaviour.collectAsState()

    var showControls by remember { mutableStateOf(true) }
    var showSettings by remember { mutableStateOf(false) }

    val openVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.setMediaUri(it) }
    }

    // শুরুতে যদি অন্য অ্যাপ থেকে ভিডিও পাঠানো হয়ে থাকে (VIEW/SEND intent)
    if (!hasMedia && initialUri != null) {
        viewModel.setMediaUri(initialUri)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { showControls = !showControls }
    ) {
        AndroidView(
            factory = { context ->
                // surface_type শুধু XML-এর মাধ্যমেই সেট করা যায় (Media3 ডকুমেন্টেশন
                // অনুযায়ী রানটাইমে PlayerView.surfaceType সেট করার কোনো পাবলিক API নেই)।
                // তাই res/layout/player_view_texture.xml থেকে inflate করছি, যেখানে
                // app:surface_type="texture_view" আগে থেকেই সেট করা আছে।
                val playerView = LayoutInflater.from(context)
                    .inflate(R.layout.player_view_texture, null) as PlayerView
                playerView.player = player
                playerView
            },
            modifier = Modifier.fillMaxSize()
        )

        if (!hasMedia) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "কোনো ভিডিও চালু নেই",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.padding(8.dp))
                Button(onClick = { openVideoLauncher.launch(arrayOf("video/*")) }) {
                    Text(stringResource(R.string.open_video))
                }
            }
        }

        if (showControls && hasMedia) {
            PlayerControls(
                isPlaying = isPlaying,
                currentPositionMs = currentPos,
                durationMs = duration,
                volume = volume,
                isMuted = isMuted,
                onPlayPauseClick = { viewModel.togglePlay() },
                onSeek = { viewModel.seekTo(it) },
                onVolumeChange = { viewModel.setVolume(it) },
                onToggleMute = { viewModel.toggleMute() },
                onSettingsClick = { showSettings = true }
            )
        }
    }

    if (showSettings) {
        SettingsSheet(
            currentBehaviour = focusBehaviour,
            onBehaviourSelected = { viewModel.setFocusLossBehaviour(it) },
            onDismiss = { showSettings = false }
        )
    }
}
