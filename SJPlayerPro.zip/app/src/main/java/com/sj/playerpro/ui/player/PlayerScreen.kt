package com.sj.playerpro.ui.player

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.view.LayoutInflater
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import com.sj.playerpro.R
import com.sj.playerpro.ui.player.components.GestureFeedbackBubble
import com.sj.playerpro.ui.player.components.PlayerControls
import com.sj.playerpro.ui.player.components.SettingsSheet
import kotlinx.coroutines.delay

private const val SEEK_STEP_MS = 10_000L
private const val FEEDBACK_HOLD_MS = 650L

/** Robustly finds the hosting Activity from a Compose Context. A plain
 *  `context as? Activity` cast can fail (returns null) if LocalContext.current
 *  is a wrapped/themed context rather than the Activity directly - this was
 *  the real cause of the brightness gesture silently doing nothing (it needs
 *  the Activity's Window; volume didn't need it, which is why only volume
 *  appeared to work). Unwrapping through ContextWrapper is the standard fix. */
private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun PlayerScreen(
    initialUri: Uri? = null,
    onBackClick: (() -> Unit)? = null,
    viewModel: PlayerViewModel = hiltViewModel()
) {
    val isPlaying by viewModel.isPlaying.collectAsState()
    val hasMedia by viewModel.hasMedia.collectAsState()
    val currentPos by viewModel.currentPositionMs.collectAsState()
    val duration by viewModel.durationMs.collectAsState()
    val volume by viewModel.volume.collectAsState()
    val isMuted by viewModel.isMuted.collectAsState()
    val focusBehaviour by viewModel.focusLossBehaviour.collectAsState()

    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }

    var showControls by remember { mutableStateOf(true) }
    var showSettings by remember { mutableStateOf(false) }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var lastLoadedUri by remember { mutableStateOf<Uri?>(null) }

    // Gesture feedback (double-tap seek / vertical-drag volume-brightness)
    var seekFeedback by remember { mutableStateOf<String?>(null) }
    var volumeFeedback by remember { mutableStateOf<String?>(null) }
    var brightnessFeedback by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(seekFeedback) {
        if (seekFeedback != null) {
            delay(FEEDBACK_HOLD_MS)
            seekFeedback = null
        }
    }
    LaunchedEffect(volumeFeedback) {
        if (volumeFeedback != null) {
            delay(FEEDBACK_HOLD_MS)
            volumeFeedback = null
        }
    }
    LaunchedEffect(brightnessFeedback) {
        if (brightnessFeedback != null) {
            delay(FEEDBACK_HOLD_MS)
            brightnessFeedback = null
        }
    }

    val targetUri = pickedUri ?: initialUri

    val openVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { pickedUri = it }
    }

    fun adjustVolume(delta: Float) {
        val newVolume = (volume + delta).coerceIn(0f, 1f)
        viewModel.setVolume(newVolume)
        volumeFeedback = "Volume ${(newVolume * 100).toInt()}%"
    }

    fun adjustBrightness(delta: Float) {
        val window = activity?.window ?: return
        val current = window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
        val newValue = (current + delta).coerceIn(0.02f, 1f)
        window.attributes = window.attributes.apply { screenBrightness = newValue }
        brightnessFeedback = "Brightness ${(newValue * 100).toInt()}%"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(hasMedia) {
                detectTapGestures(
                    onTap = { showControls = !showControls },
                    onDoubleTap = { offset ->
                        if (!hasMedia) return@detectTapGestures
                        val third = size.width / 3
                        when {
                            offset.x < third -> {
                                viewModel.seekTo((currentPos - SEEK_STEP_MS).coerceAtLeast(0))
                                seekFeedback = "-10s"
                            }
                            offset.x > third * 2 -> {
                                viewModel.seekTo((currentPos + SEEK_STEP_MS).coerceAtMost(duration))
                                seekFeedback = "+10s"
                            }
                            else -> viewModel.togglePlay()
                        }
                    }
                )
            }
            .pointerInput(hasMedia) {
                if (!hasMedia) return@pointerInput
                detectVerticalDragGestures { change, dragAmount ->
                    change.consume()
                    // dragging up = increase; height-normalized so a full-screen
                    // swipe covers roughly the full 0..1 range.
                    val delta = -dragAmount / size.height.toFloat()
                    if (change.position.x < size.width / 2) {
                        adjustBrightness(delta)
                    } else {
                        adjustVolume(delta)
                    }
                }
            }
    ) {
        AndroidView(
            factory = { ctx ->
                (LayoutInflater.from(ctx).inflate(R.layout.mpv_view, null) as SJMpvView).apply {
                    ensureInitialized()
                    viewModel.registerWithMpv()
                }
            },
            update = { view ->
                if (targetUri != null && targetUri != lastLoadedUri) {
                    runCatching { view.playFile(targetUri.toString()) }
                        .onFailure { viewModel.reportError("playFile failed: ${it.message}") }
                    lastLoadedUri = targetUri
                    viewModel.onFileLoaded(targetUri)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        GestureFeedbackBubble(seekFeedback, alignment = Alignment.Center)
        GestureFeedbackBubble(volumeFeedback, alignment = Alignment.CenterEnd)
        GestureFeedbackBubble(brightnessFeedback, alignment = Alignment.CenterStart)

        if (onBackClick != null) {
            AnimatedVisibility(
                visible = showControls,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(top = 4.dp, start = 8.dp)
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to library",
                        tint = Color.White
                    )
                }
            }
        }

        if (!hasMedia) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "No video playing",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.padding(8.dp))
                Button(onClick = { openVideoLauncher.launch(arrayOf("video/*")) }) {
                    Text(stringResource(R.string.open_video))
                }
            }
        }

        // BUG FIX: this previously had no alignment, which defaults to
        // TopStart in a Box - that's why the control bar was appearing at
        // the top instead of the bottom.
        AnimatedVisibility(
            visible = showControls && hasMedia,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .windowInsetsPadding(WindowInsets.navigationBars)
        ) {
            PlayerControls(
                isPlaying = isPlaying,
                currentPositionMs = currentPos,
                durationMs = duration,
                volume = volume,
                isMuted = isMuted,
                onPlayPauseClick = { viewModel.togglePlay() },
                onSeek = { viewModel.seekTo(it) },
                onVolumeChange = { viewModel.setVolume(it) },
                onToggleMute = { viewModel.toggleMute() },
                onSettingsClick = { showSettings = true }
            )
        }
    }

    if (showSettings) {
        SettingsSheet(
            currentBehaviour = focusBehaviour,
            onBehaviourSelected = { viewModel.setFocusLossBehaviour(it) },
            onDismiss = { showSettings = false }
        )
    }
}
