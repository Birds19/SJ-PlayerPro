package com.sj.playerpro.ui.player

import android.app.Activity
import android.net.Uri
import android.view.LayoutInflater
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import com.sj.playerpro.R
import com.sj.playerpro.ui.player.components.GestureFeedbackBubble
import com.sj.playerpro.ui.player.components.PlayerControls
import com.sj.playerpro.ui.player.components.SettingsSheet
import kotlinx.coroutines.delay

private const val SEEK_STEP_MS = 10_000L
private const val FEEDBACK_HOLD_MS = 650L

@Composable
fun PlayerScreen(
    initialUri: Uri? = null,
    onBackClick: (() -> Unit)? = null,
    viewModel: PlayerViewModel = hiltViewModel()
) {
    val isPlaying by viewModel.isPlaying.collectAsState()
    val hasMedia by viewModel.hasMedia.collectAsState()
    val currentPos by viewModel.currentPositionMs.collectAsState()
    val duration by viewModel.durationMs.collectAsState()
    val volume by viewModel.volume.collectAsState()
    val isMuted by viewModel.isMuted.collectAsState()
    val focusBehaviour by viewModel.focusLossBehaviour.collectAsState()

    val context = LocalContext.current
    val activity = context as? Activity

    var showControls by remember { mutableStateOf(true) }
    var showSettings by remember { mutableStateOf(false) }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var lastLoadedUri by remember { mutableStateOf<Uri?>(null) }

    // Gesture feedback (double-tap seek / vertical-drag volume-brightness)
    var seekFeedback by remember { mutableStateOf<String?>(null) }
    var volumeFeedback by remember { mutableStateOf<String?>(null) }
    var brightnessFeedback by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(seekFeedback) {
        if (seekFeedback != null) {
            delay(FEEDBACK_HOLD_MS)
            seekFeedback = null
        }
    }
    LaunchedEffect(volumeFeedback) {
        if (volumeFeedback != null) {
            delay(FEEDBACK_HOLD_MS)
            volumeFeedback = null
        }
    }
    LaunchedEffect(brightnessFeedback) {
        if (brightnessFeedback != null) {
            delay(FEEDBACK_HOLD_MS)
            brightnessFeedback = null
        }
    }

    val targetUri = pickedUri ?: initialUri

    val openVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { pickedUri = it }
    }

    fun adjustVolume(delta: Float) {
        val newVolume = (volume + delta).coerceIn(0f, 1f)
        viewModel.setVolume(newVolume)
        volumeFeedback = "Volume ${(newVolume * 100).toInt()}%"
    }

    fun adjustBrightness(delta: Float) {
        val window = activity?.window ?: return
        val current = window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
        val newValue = (current + delta).coerceIn(0.02f, 1f)
        window.attributes = window.attributes.apply { screenBrightness = newValue }
        brightnessFeedback = "Brightness ${(newValue * 100).toInt()}%"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(hasMedia) {
                detectTapGestures(
                    onTap = { showControls = !showControls },
                    onDoubleTap = { offset ->
                        if (!hasMedia) return@detectTapGestures
                        val third = size.width / 3
                        when {
                            offset.x < third -> {
                                viewModel.seekTo((currentPos - SEEK_STEP_MS).coerceAtLeast(0))
                                seekFeedback = "-10s"
                            }
                            offset.x > third * 2 -> {
                                viewModel.seekTo((currentPos + SEEK_STEP_MS).coerceAtMost(duration))
                                seekFeedback = "+10s"
                            }
                            else -> viewModel.togglePlay()
                        }
                    }
                )
            }
            .pointerInput(hasMedia) {
                if (!hasMedia) return@pointerInput
                detectVerticalDragGestures { change, dragAmount ->
                    change.consume()
                    // dragging up = increase; height-normalized so a full-screen
                    // swipe covers roughly the full 0..1 range.
                    val delta = -dragAmount / size.height.toFloat()
                    if (change.position.x < size.width / 2) {
                        adjustBrightness(delta)
                    } else {
                        adjustVolume(delta)
                    }
                }
            }
    ) {
        AndroidView(
            factory = { ctx ->
                (LayoutInflater.from(ctx).inflate(R.layout.mpv_view, null) as SJMpvView).apply {
                    ensureInitialized()
                    viewModel.registerWithMpv()
                }
            },
            update = { view ->
                if (targetUri != null && targetUri != lastLoadedUri) {
                    runCatching { view.playFile(targetUri.toString()) }
                        .onFailure { viewModel.reportError("playFile failed: ${it.message}") }
                    lastLoadedUri = targetUri
                    viewModel.onFileLoaded(targetUri)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        GestureFeedbackBubble(seekFeedback, alignment = Alignment.Center)
        GestureFeedbackBubble(volumeFeedback, alignment = Alignment.CenterEnd)
        GestureFeedbackBubble(brightnessFeedback, alignment = Alignment.CenterStart)

        if (onBackClick != null) {
            AnimatedVisibility(
                visible = showControls,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.padding(top = 16.dp, start = 8.dp)
            ) {
                androidx.compose.material3.IconButton(onClick = onBackClick) {
                    androidx.compose.material3.Icon(
                        imageVector = androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to library",
                        tint = Color.White
                    )
                }
            }
        }

        if (!hasMedia) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "No video playing",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.padding(8.dp))
                Button(onClick = { openVideoLauncher.launch(arrayOf("video/*")) }) {
                    Text(stringResource(R.string.open_video))
                }
            }
        }

        AnimatedVisibility(
            visible = showControls && hasMedia,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            PlayerControls(
                isPlaying = isPlaying,
                currentPositionMs = currentPos,
                durationMs = duration,
                volume = volume,
                isMuted = isMuted,
                onPlayPauseClick = { viewModel.togglePlay() },
                onSeek = { viewModel.seekTo(it) },
                onVolumeChange = { viewModel.setVolume(it) },
                onToggleMute = { viewModel.toggleMute() },
                onSettingsClick = { showSettings = true }
            )
        }
    }

    if (showSettings) {
        SettingsSheet(
            currentBehaviour = focusBehaviour,
            onBehaviourSelected = { viewModel.setFocusLossBehaviour(it) },
            onDismiss = { showSettings = false }
        )
    }
}
