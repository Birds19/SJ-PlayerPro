package com.sj.playerpro.ui.player

import android.net.Uri
import android.view.LayoutInflater
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import com.sj.playerpro.R
import com.sj.playerpro.ui.player.components.PlayerControls
import com.sj.playerpro.ui.player.components.SettingsSheet

@Composable
fun PlayerScreen(
    initialUri: Uri? = null,
    viewModel: PlayerViewModel = hiltViewModel()
) {
    val isPlaying by viewModel.isPlaying.collectAsState()
    val hasMedia by viewModel.hasMedia.collectAsState()
    val currentPos by viewModel.currentPositionMs.collectAsState()
    val duration by viewModel.durationMs.collectAsState()
    val volume by viewModel.volume.collectAsState()
    val isMuted by viewModel.isMuted.collectAsState()
    val focusBehaviour by viewModel.focusLossBehaviour.collectAsState()

    var showControls by remember { mutableStateOf(true) }
    var showSettings by remember { mutableStateOf(false) }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var lastLoadedUri by remember { mutableStateOf<Uri?>(null) }

    val targetUri = pickedUri ?: initialUri

    val openVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { pickedUri = it }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { showControls = !showControls }
    ) {
        AndroidView(
            factory = { context ->
                (LayoutInflater.from(context).inflate(R.layout.mpv_view, null) as SJMpvView).apply {
                    ensureInitialized()
                    viewModel.registerWithMpv()
                }
            },
            update = { view ->
                if (targetUri != null && targetUri != lastLoadedUri) {
                    runCatching { view.playFile(targetUri.toString()) }
                        .onFailure { viewModel.reportError("playFile failed: ${it.message}") }
                    lastLoadedUri = targetUri
                    viewModel.onFileLoaded()
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (!hasMedia) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "No video playing",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.padding(8.dp))
                Button(onClick = { openVideoLauncher.launch(arrayOf("video/*")) }) {
                    Text(stringResource(R.string.open_video))
                }
            }
        }

        if (showControls && hasMedia) {
            PlayerControls(
                isPlaying = isPlaying,
                currentPositionMs = currentPos,
                durationMs = duration,
                volume = volume,
                isMuted = isMuted,
                onPlayPauseClick = { viewModel.togglePlay() },
                onSeek = { viewModel.seekTo(it) },
                onVolumeChange = { viewModel.setVolume(it) },
                onToggleMute = { viewModel.toggleMute() },
                onSettingsClick = { showSettings = true }
            )
        }
    }

    if (showSettings) {
        SettingsSheet(
            currentBehaviour = focusBehaviour,
            onBehaviourSelected = { viewModel.setFocusLossBehaviour(it) },
            onDismiss = { showSettings = false }
        )
    }
}
