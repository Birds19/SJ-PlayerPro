package com.sj.playerpro.ui.player

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sj.playerpro.audio.AudioFocusController
import com.sj.playerpro.audio.AudioFocusSettings
import com.sj.playerpro.data.WatchStateDao
import com.sj.playerpro.data.WatchStateEntity
import com.sj.playerpro.model.FocusLossBehaviour
import dagger.hilt.android.lifecycle.HiltViewModel
import `is`.xyz.mpv.MPVLib
import `is`.xyz.mpv.MPVNode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val WATCHED_THRESHOLD = 0.9f
private const val PROGRESS_SAVE_INTERVAL_MS = 5_000L

/**
 * Unlike the old Media3/ExoPlayer version, this ViewModel does NOT hold a
 * "player" object - MPVLib is a static, process-wide bridge to a single
 * native mpv instance (there's only ever one). The ViewModel:
 *   1) mirrors native player state into StateFlows for Compose, and
 *   2) issues MPVLib property/command calls in response to UI actions.
 *
 * The actual video surface (SJMpvView) lives in Compose (PlayerScreen.kt),
 * not here - Views shouldn't be held by ViewModels. PlayerScreen registers
 * this ViewModel as the MPVLib.EventObserver once the view is initialized
 * (see registerWithMpv()).
 *
 * Also now tracks watch progress (position/watched flag) per video URI in
 * Room, powering the progress bar / watched badge on the Library screen.
 */
@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val audioFocusController: AudioFocusController,
    private val watchStateDao: WatchStateDao
) : ViewModel(), MPVLib.EventObserver {

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _hasMedia = MutableStateFlow(false)
    val hasMedia: StateFlow<Boolean> = _hasMedia

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs

    private val _volume = MutableStateFlow(1f) // normalized 0f..1f (mpv itself uses 0..100)
    val volume: StateFlow<Float> = _volume

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted

    val focusLossBehaviour: StateFlow<FocusLossBehaviour> = AudioFocusSettings.focusLossBehaviour

    private var isRegisteredWithMpv = false
    private var currentUri: Uri? = null
    private var progressSaveJob: kotlinx.coroutines.Job? = null

    /** Called once from PlayerScreen right after SJMpvView.ensureInitialized().
     *  Property observation itself is registered by SJMpvView.observeProperties()
     *  (called internally by BaseMPVView) - this just wires up the callback
     *  receiver and requests Android audio focus. */
    fun registerWithMpv() {
        if (isRegisteredWithMpv) return
        MPVLib.addObserver(this)
        isRegisteredWithMpv = true
        audioFocusController.requestFocus()
    }

    fun onFileLoaded(uri: Uri) {
        _hasMedia.value = true
        currentUri = uri
        startProgressSaveLoop()
    }

    private fun startProgressSaveLoop() {
        progressSaveJob?.cancel()
        progressSaveJob = viewModelScope.launch {
            while (isActive) {
                delay(PROGRESS_SAVE_INTERVAL_MS)
                saveProgress()
            }
        }
    }

    private fun saveProgress() {
        val uri = currentUri ?: return
        val duration = _durationMs.value
        if (duration <= 0) return
        val position = _currentPositionMs.value
        val watched = position >= duration * WATCHED_THRESHOLD
        viewModelScope.launch {
            runCatching {
                watchStateDao.upsert(
                    WatchStateEntity(
                        videoUriString = uri.toString(),
                        lastPositionMs = position,
                        durationMs = duration,
                        isWatched = watched,
                        lastPlayedAtMs = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    fun togglePlay() {
        runCatching { MPVLib.setPropertyBoolean("pause", _isPlaying.value) }
        if (!_isPlaying.value) saveProgress() // save immediately on pause
    }

    fun seekTo(positionMs: Long) {
        runCatching { MPVLib.setPropertyDouble("time-pos", positionMs / 1000.0) }
    }

    fun setVolume(newVolume: Float) {
        val clamped = newVolume.coerceIn(0f, 1f)
        runCatching { MPVLib.setPropertyInt("volume", (clamped * 100).toInt()) }
    }

    fun toggleMute() {
        runCatching { MPVLib.setPropertyBoolean("mute", !_isMuted.value) }
    }

    fun setFocusLossBehaviour(behaviour: FocusLossBehaviour) {
        AudioFocusSettings.focusLossBehaviour.value = behaviour
    }

    fun reportError(message: String) {
        Log.e("SJPlayerPro", message)
    }

    // ---- MPVLib.EventObserver ----

    override fun eventProperty(property: String) {
        // no-op: we only care about the typed overloads below for our tracked properties
    }

    override fun eventProperty(property: String, value: Boolean) {
        when (property) {
            "pause" -> _isPlaying.value = !value
            "mute" -> _isMuted.value = value
        }
    }

    override fun eventProperty(property: String, value: Long) {
        if (property == "volume") {
            _volume.value = (value / 100f).coerceIn(0f, 1f)
        }
    }

    override fun eventProperty(property: String, value: Double) {
        when (property) {
            "time-pos" -> _currentPositionMs.value = (value * 1000).toLong().coerceAtLeast(0)
            "duration" -> _durationMs.value = (value * 1000).toLong().coerceAtLeast(0)
        }
    }

    override fun eventProperty(property: String, value: String) {
        // not currently used
    }

    override fun eventProperty(property: String, value: MPVNode) {
        // not currently used
    }

    override fun event(eventId: Int, data: MPVNode) {
        // not currently used - reserved for playback-start/end/idle events later
    }

    override fun onCleared() {
        super.onCleared()
        saveProgress()
        progressSaveJob?.cancel()
        if (isRegisteredWithMpv) {
            runCatching { MPVLib.removeObserver(this) }
            runCatching { MPVLib.destroy() }
        }
    }
}
