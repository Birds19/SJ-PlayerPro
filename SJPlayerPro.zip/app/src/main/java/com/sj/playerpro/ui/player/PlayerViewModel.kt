package com.sj.playerpro.ui.player

import androidx.lifecycle.ViewModel
import com.sj.playerpro.audio.AudioFocusController
import com.sj.playerpro.audio.AudioFocusSettings
import com.sj.playerpro.model.FocusLossBehaviour
import dagger.hilt.android.lifecycle.HiltViewModel
import `is`.xyz.mpv.MPVLib
import `is`.xyz.mpv.MPVNode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

/**
 * Unlike the old Media3/ExoPlayer version, this ViewModel does NOT hold a
 * "player" object - MPVLib is a static, process-wide bridge to a single
 * native mpv instance (there's only ever one). The ViewModel:
 *   1) mirrors native player state into StateFlows for Compose, and
 *   2) issues MPVLib property/command calls in response to UI actions.
 *
 * The actual video surface (SJMpvView) lives in Compose (PlayerScreen.kt),
 * not here - Views shouldn't be held by ViewModels. PlayerScreen registers
 * this ViewModel as the MPVLib.EventObserver once the view is initialized
 * (see registerWithMpv()).
 *
 * Property names, formats, and the play/pause/seek/volume approach are all
 * verified against mpvRex's actual source (MPVView.kt / MediaPlaybackService.kt),
 * not guessed.
 */
@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val audioFocusController: AudioFocusController
) : ViewModel(), MPVLib.EventObserver {

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _hasMedia = MutableStateFlow(false)
    val hasMedia: StateFlow<Boolean> = _hasMedia

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs

    private val _volume = MutableStateFlow(1f) // normalized 0f..1f (mpv itself uses 0..100)
    val volume: StateFlow<Float> = _volume

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted

    val focusLossBehaviour: StateFlow<FocusLossBehaviour> = AudioFocusSettings.focusLossBehaviour

    private var isRegisteredWithMpv = false

    /** Called once from PlayerScreen right after SJMpvView.ensureInitialized().
     *  Property observation itself is registered by SJMpvView.observeProperties()
     *  (called internally by BaseMPVView) - this just wires up the callback
     *  receiver and requests Android audio focus. */
    fun registerWithMpv() {
        if (isRegisteredWithMpv) return
        MPVLib.addObserver(this)
        isRegisteredWithMpv = true
        audioFocusController.requestFocus()
    }

    fun onFileLoaded() {
        _hasMedia.value = true
    }

    fun togglePlay() {
        runCatching { MPVLib.setPropertyBoolean("pause", _isPlaying.value) }
    }

    fun seekTo(positionMs: Long) {
        runCatching { MPVLib.setPropertyDouble("time-pos", positionMs / 1000.0) }
    }

    fun setVolume(newVolume: Float) {
        val clamped = newVolume.coerceIn(0f, 1f)
        runCatching { MPVLib.setPropertyInt("volume", (clamped * 100).toInt()) }
    }

    fun toggleMute() {
        runCatching { MPVLib.setPropertyBoolean("mute", !_isMuted.value) }
    }

    fun setFocusLossBehaviour(behaviour: FocusLossBehaviour) {
        AudioFocusSettings.focusLossBehaviour.value = behaviour
    }

    // ---- MPVLib.EventObserver ----

    override fun eventProperty(property: String) {
        // no-op: we only care about the typed overloads below for our tracked properties
    }

    override fun eventProperty(property: String, value: Boolean) {
        when (property) {
            "pause" -> _isPlaying.value = !value
            "mute" -> _isMuted.value = value
        }
    }

    override fun eventProperty(property: String, value: Long) {
        if (property == "volume") {
            _volume.value = (value / 100f).coerceIn(0f, 1f)
        }
    }

    override fun eventProperty(property: String, value: Double) {
        when (property) {
            "time-pos" -> _currentPositionMs.value = (value * 1000).toLong().coerceAtLeast(0)
            "duration" -> _durationMs.value = (value * 1000).toLong().coerceAtLeast(0)
        }
    }

    override fun eventProperty(property: String, value: String) {
        // not currently used
    }

    override fun eventProperty(property: String, value: MPVNode) {
        // not currently used
    }

    override fun event(eventId: Int, data: MPVNode) {
        // not currently used - reserved for playback-start/end/idle events later
    }

    override fun onCleared() {
        super.onCleared()
        if (isRegisteredWithMpv) {
            runCatching { MPVLib.removeObserver(this) }
            runCatching { MPVLib.destroy() }
        }
    }
}
