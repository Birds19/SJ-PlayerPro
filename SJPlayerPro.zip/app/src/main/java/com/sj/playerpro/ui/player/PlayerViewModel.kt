package com.sj.playerpro.ui.player

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.sj.playerpro.audio.AudioFocusSettings
import com.sj.playerpro.model.FocusLossBehaviour
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlayerViewModel @Inject constructor(
    val player: ExoPlayer
) : ViewModel() {

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _hasMedia = MutableStateFlow(false)
    val hasMedia: StateFlow<Boolean> = _hasMedia

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs

    private val _volume = MutableStateFlow(1f)
    val volume: StateFlow<Float> = _volume

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted

    val focusLossBehaviour: StateFlow<FocusLossBehaviour> = AudioFocusSettings.focusLossBehaviour

    private var savedVolume = 1f

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    _durationMs.value = player.duration.coerceAtLeast(0)
                }
            }
        })

        viewModelScope.launch {
            while (isActive) {
                if (player.playbackState == Player.STATE_READY) {
                    _currentPositionMs.value = player.currentPosition.coerceAtLeast(0)
                    _durationMs.value = player.duration.coerceAtLeast(0)
                }
                _volume.value = player.volume
                _isMuted.value = player.volume == 0f
                delay(250)
            }
        }
    }

    fun setMediaUri(uri: Uri) {
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.playWhenReady = true
        _hasMedia.value = true
    }

    fun togglePlay() {
        if (player.playWhenReady) player.pause() else player.play()
    }

    fun seekTo(positionMs: Long) {
        player.seekTo(positionMs)
    }

    fun setVolume(newVolume: Float) {
        player.volume = newVolume.coerceIn(0f, 1f)
        savedVolume = player.volume
    }

    fun toggleMute() {
        if (player.volume > 0f) {
            savedVolume = player.volume
            player.volume = 0f
        } else {
            player.volume = savedVolume.coerceAtLeast(0.1f)
        }
    }

    fun setFocusLossBehaviour(behaviour: FocusLossBehaviour) {
        AudioFocusSettings.focusLossBehaviour.value = behaviour
    }

    override fun onCleared() {
        super.onCleared()
        player.release()
    }
}
