package com.sj.playerpro.di

import android.app.Application
import android.content.Context
import android.media.AudioManager
import com.sj.playerpro.audio.AudioFocusController
import com.sj.playerpro.audio.AudioFocusSettings
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * No ExoPlayer/DefaultRenderersFactory here anymore - libmpv (via MPVLib) is
 * a static, process-wide bridge, not a per-instance object Hilt needs to
 * construct. Only the Android-side audio focus plumbing is provided here.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideAudioManager(app: Application): AudioManager =
        app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Provides
    @Singleton
    fun provideAudioFocusController(
        app: Application,
        audioManager: AudioManager
    ): AudioFocusController =
        AudioFocusController(app, audioManager, AudioFocusSettings.focusLossBehaviour)
}
