package com.sj.playerpro.di

import android.app.Application
import android.content.Context
import android.media.AudioManager
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import com.sj.playerpro.audio.AudioFocusController
import com.sj.playerpro.audio.AudioFocusSettings
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideAudioManager(app: Application): AudioManager =
        app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Provides
    @Singleton
    fun provideAudioFocusController(
        app: Application,
        audioManager: AudioManager
    ): AudioFocusController =
        AudioFocusController(app, audioManager, AudioFocusSettings.focusLossBehaviour)

    @Provides
    @Singleton
    fun provideExoPlayer(
        app: Application,
        focusController: AudioFocusController
    ): ExoPlayer {
        // EXTENSION_RENDERER_MODE_PREFER: use a decoder extension (e.g. a
        // manually-built media3-decoder-ffmpeg module) automatically if it's
        // ever present on the classpath, otherwise fall back to Media3's
        // built-in platform decoders. This means FFmpeg support can be added
        // later purely by adding the dependency - no code change needed here.
        val renderersFactory = DefaultRenderersFactory(app)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)

        val mediaAudioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val player = ExoPlayer.Builder(app, renderersFactory)
            // handleAudioFocus = false: we manage focus ourselves via
            // AudioFocusController so playback never auto-pauses on focus loss.
            .setAudioAttributes(mediaAudioAttributes, /* handleAudioFocus = */ false)
            .setHandleAudioBecomingNoisy(true)
            .build()

        focusController.attachPlayer(player)
        focusController.requestFocus()

        return player
    }
}
