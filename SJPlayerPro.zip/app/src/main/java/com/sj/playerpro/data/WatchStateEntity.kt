package com.sj.playerpro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Our own watch-progress record for a video, keyed by its MediaStore content
 * URI (as a string, since Room needs a simple primary key type). MediaStore
 * itself doesn't track per-app "have I watched this" state, so this is what
 * powers the watched/in-progress indicators in the library grid.
 */
@Entity(tableName = "watch_state")
data class WatchStateEntity(
    @PrimaryKey val videoUriString: String,
    val lastPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isWatched: Boolean = false,
    val lastPlayedAtMs: Long = System.currentTimeMillis()
)
