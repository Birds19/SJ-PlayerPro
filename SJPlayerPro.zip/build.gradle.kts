// SJ Player Pro - root build file
// Versions pinned deliberately (see README.md "Version Decisions" section)
// to avoid the AGP 9.x breaking migration (built-in Kotlin support) while
// still being a current, stable, well-documented combination.
// AGP 8.10.0 specifically: KSP 2.3.10 (needed for Kotlin 2.4.10) explicitly
// requires AGP >= 8.10.0 to apply at all ("The minimum supported AGP version
// is 8.10.0"). Still 8.x line, still avoids the AGP 9 built-in-Kotlin migration,
// and confirmed to support compileSdk up to 36 (max API level for AGP 8.10 is 36).
// Kotlin 2.3.10 (NOT the newest 2.4.10): Hilt 2.58's kotlin-metadata-jvm
// reader only accepts metadata format up to 2.3.0, and Kotlin 2.4.x emits
// 2.4.0-format metadata that breaks hiltJavaCompileDebug even on Hilt's own
// latest release (2.59.2 - see google/dagger#5190, open/unresolved). Forcing
// kotlin-metadata-jvm to a newer version did NOT fix it either (the failing
// code path uses Dagger's internally-shaded copy, unreachable via normal
// Gradle dependency resolution). Kotlin's own docs explicitly recommend
// "AGP 8.x + Kotlin 2.3.10" as the compatible pairing, which is what this is.
// Note: the earlier Kotlin 2.4.10 bump was originally to fix a Compose BOM
// "internal in file" error - but that error's real cause turned out to be an
// unrelated bad import (see PlayerControls.kt history), not a Kotlin version
// issue, so downgrading here does not reintroduce that problem.
// KSP 2.3.10 is version-independent of Kotlin as of KSP 2.3.0+ ("KSP 2.3.0
// should work with Kotlin 2.2.* and newer" - google/ksp team), so it needs
// no change here.
// Hilt 2.58: 2.59+ dropped AGP 8.x support (Gradle plugin now requires AGP 9),
// so 2.58 is the newest release still compatible with our AGP 8.9.1. It also
// includes Dagger's kotlin-metadata-jvm fix needed to correctly parse
// Kotlin 2.3+/2.4.10-generated metadata (older Hilt releases choke on it).
plugins {
    id("com.android.application") version "8.10.0" apply false
    id("org.jetbrains.kotlin.android") version "2.3.10" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.10" apply false
    id("com.google.devtools.ksp") version "2.3.10" apply false
    id("com.google.dagger.hilt.android") version "2.58" apply false
}
