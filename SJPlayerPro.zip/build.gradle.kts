// SJ Player Pro - root build file
// Versions pinned deliberately (see README.md "Version Decisions" section)
// to avoid the AGP 9.x breaking migration (built-in Kotlin support) while
// still being a current, stable, well-documented combination.
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.28" apply false
    id("com.google.dagger.hilt.android") version "2.56" apply false
}
