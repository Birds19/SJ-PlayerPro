// SJ Player Pro - root build file
// Versions pinned deliberately (see README.md "Version Decisions" section)
// to avoid the AGP 9.x breaking migration (built-in Kotlin support) while
// still being a current, stable, well-documented combination.
// AGP 8.9.1 specifically chosen because it's the last-8.x-line version that
// supports compileSdk 36, which Media3 1.10.0 requires (see AAR metadata check).
// Kotlin 2.4.10 (current stable as of this build, not an intermediate guess):
// the Kotlin/Compose compiler MUST be the same age or newer than the Compose
// library metadata it's reading. Kotlin 2.0.21, then 2.2.20, both still older
// than what Compose BOM 2026.01.00's libraries were built with, causing
// "internal in file" errors on Compose framework internals (e.g.
// RowColumnParentData.weight). Using the actual current stable Kotlin release
// removes this whole class of error instead of guessing another midpoint version.
// KSP 2.3.10 is the version officially paired with Kotlin 2.4.10 per
// kotlinlang.org's own KSP quickstart guide (KSP has moved to independent
// versioning, no longer strictly prefixed with the Kotlin version).
// Hilt 2.58: 2.59+ dropped AGP 8.x support (Gradle plugin now requires AGP 9),
// so 2.58 is the newest release still compatible with our AGP 8.9.1. It also
// includes Dagger's kotlin-metadata-jvm fix needed to correctly parse
// Kotlin 2.3+/2.4.10-generated metadata (older Hilt releases choke on it).
plugins {
    id("com.android.application") version "8.9.1" apply false
    id("org.jetbrains.kotlin.android") version "2.4.10" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.10" apply false
    id("com.google.devtools.ksp") version "2.3.10" apply false
    id("com.google.dagger.hilt.android") version "2.58" apply false
}
