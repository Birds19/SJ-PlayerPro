// SJ Player Pro - root build file
// Versions pinned deliberately (see README.md "Version Decisions" section)
// to avoid the AGP 9.x breaking migration (built-in Kotlin support) while
// still being a current, stable, well-documented combination.
// AGP 8.9.1 specifically chosen because it's the last-8.x-line version that
// supports compileSdk 36, which Media3 1.10.0 requires (see AAR metadata check).
// Kotlin 2.2.20 specifically chosen because Compose BOM 2026.01.00 requires it
// (an older Kotlin here causes "internal in file" errors on Compose internals
// like RowColumnParentData - a Compose-compiler/runtime ABI mismatch, not a code bug).
plugins {
    id("com.android.application") version "8.9.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.20" apply false
    id("com.google.devtools.ksp") version "2.2.20-2.0.3" apply false
    id("com.google.dagger.hilt.android") version "2.56" apply false
}
