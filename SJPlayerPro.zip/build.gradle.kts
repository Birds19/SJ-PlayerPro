// SJ Player Pro - root build file
// Versions pinned deliberately (see README.md "Version Decisions" section)
// to avoid the AGP 9.x breaking migration (built-in Kotlin support) while
// still being a current, stable, well-documented combination.
// AGP 8.9.1 specifically chosen because it's the last-8.x-line version that
// supports compileSdk 36, which Media3 1.10.0 requires (see AAR metadata check).
plugins {
    id("com.android.application") version "8.9.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.28" apply false
    id("com.google.dagger.hilt.android") version "2.56" apply false
}
